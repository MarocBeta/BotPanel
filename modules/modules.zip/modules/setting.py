#!/usr/bin/env python3

import re
import json
import asyncio
import requests
import datetime
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'reboot-server'))
async def reboot(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        inline_buttons = [
            [Button.inline("Yes", b'confirm_reboot_yes'), Button.inline("No", b'confirm_reboot_no')]
        ]
        await event.respond("**Confirm Reboot Server?**", buttons=inline_buttons)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'confirm_reboot_yes'))
async def confirm_reboot_yes(event):
    try:
        inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
        await event.edit("**Rebooting the server... Please wait...**", buttons=None)
        await asyncio.sleep(1)
        await event.edit("**Reboot Server Successfully!**", buttons=inline)
        subprocess.Popen("reboot", shell=True)
    except Exception as e:
        await event.respond(f"**Failed to reboot the server:** {e}")

@bot.on(events.CallbackQuery(data=b'confirm_reboot_no'))
async def confirm_reboot_no(event):
    inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
    await event.edit("**Reboot Server Canceled!**", buttons=inline)
    
@bot.on(events.CallbackQuery(data=b'restart-botpanel'))
async def restart_botpanel(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        inline_buttons = [
            [Button.inline("Yes", b'confirm_restart_yes'), Button.inline("No", b'confirm_restart_no')]
        ]
        await event.respond("**Confirm Restart BotPanel?**", buttons=inline_buttons)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'confirm_restart_yes'))
async def confirm_restart_yes(event):
    try:
        inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
        await event.edit("**Restarting the BotPanel... Please wait...**", buttons=None)
        await asyncio.sleep(1)
        subprocess.Popen("systemctl restart BotPanel", shell=True)
        await event.edit("**BotPanel Restarted Successfully!**", buttons=inline)
    except Exception as e:
        await event.respond(f"**Failed to restart the BotPanel:** {e}")

@bot.on(events.CallbackQuery(data=b'confirm_restart_no'))
async def confirm_restart_no(event):
    inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
    await event.edit("**Restart BotPanel Canceled!**", buttons=inline)
    
@bot.on(events.CallbackQuery(data=b'backup-server'))
async def server_backup(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        inline = [
            [Button.inline("Backup via QuAx", "backup-quax")],
            [Button.inline("Backup via Catbox", "backup-catbox")],
            [Button.inline("‹ Back Menu ›", "menu-setting")]
        ]
        await event.edit("**Select Backup Method:**", buttons=inline)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'backup-quax'))
async def server_backup_quax(event):
    async def server_backup_(event):
        try:
            await event.delete()
            msg = await event.respond("**Initiating server backup via QuAx...**")
            subprocess.run('rm -rf /root/backup && mkdir /root/backup && mkdir /root/backup/html', shell=True)

            backup_commands = [
                'cp /etc/passwd /root/backup/',
                'cp /etc/group /root/backup/',
                'cp /etc/shadow /root/backup/',
                'cp /etc/gshadow /root/backup/',
                'cp /etc/crontab /root/backup/',
                'cp /etc/vmess/.vmess.db /root/backup/',
                'cp /etc/ssh/.ssh.db /root/backup/',
                'cp /etc/vless/.vless.db /root/backup/',
                'cp /etc/trojan/.trojan.db /root/backup/',
                'cp /etc/bot/.bot.db /root/backup/',
                'cp -r /etc/rs/limit /root/backup/',
                'cp -r /etc/vmess /root/backup/vmess',
                'cp -r /etc/trojan /root/backup/trojan',
                'cp -r /etc/vless /root/backup/vless',
                'cp -r /etc/slowdns /root/backup/',
                'cp -r /etc/xray /root/backup/xray',
                'find /var/www/html/ -type f -name "*.html" ! -name "index.html" -exec cp {} /root/backup/html/ \;'
            ]

            for command in backup_commands:
                subprocess.run(command, shell=True)

            IP = requests.get('https://ipinfo.io/ip').text.strip()
            now = datetime.datetime.now()
            date = now.strftime('%Y-%m-%d')
            dates = now.strftime('%d %B %Y')
            time = now.strftime('%H:%M')
            zip_filename = f"{IP}-{date}.zip"
            subprocess.run(f'cd /root && zip -r {zip_filename} backup > /dev/null 2>&1', shell=True)

            upload_command = f'curl -s -X POST -F "files[]=@/root/{zip_filename}" -F "expiry=permanent" https://qu.ax/upload.php'
            quax_response = subprocess.getoutput(upload_command)
            quax_data = json.loads(quax_response)
            quax_url = quax_data["files"][0]["url"]

            backup_details = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Backup Server Successfully ⟩**
**◇━━━━━━━━━━━━━━━━◇**
» **IP      :** `{IP}`
» **Link    :** [Download Backup]({quax_url})
» **Date    :** `{dates}`
» **Time    :** `{time} WIB`
**◇━━━━━━━━━━━━━━━━◇**
"""
            inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
            await msg.edit(f"{backup_details}", buttons=inline)

            cleanup_command = f'rm -rf /root/backup /root/{zip_filename}'
            subprocess.run(cleanup_command, shell=True)

        except Exception as e:
            await event.respond(f"**Failed to backup the server:** {e}")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await server_backup_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'backup-catbox'))
async def server_backup_catbox(event):
    async def server_backup_(event):
        try:
            await event.delete()
            msg = await event.respond("**Initiating server backup via Catbox...**")
            subprocess.run('rm -rf /root/backup && mkdir /root/backup && mkdir /root/backup/html', shell=True)

            backup_commands = [
                'cp /etc/passwd /root/backup/',
                'cp /etc/group /root/backup/',
                'cp /etc/shadow /root/backup/',
                'cp /etc/gshadow /root/backup/',
                'cp /etc/crontab /root/backup/',
                'cp /etc/vmess/.vmess.db /root/backup/',
                'cp /etc/ssh/.ssh.db /root/backup/',
                'cp /etc/vless/.vless.db /root/backup/',
                'cp /etc/trojan/.trojan.db /root/backup/',
                'cp /etc/bot/.bot.db /root/backup/',
                'cp -r /etc/rs/limit /root/backup/',
                'cp -r /etc/vmess /root/backup/vmess',
                'cp -r /etc/trojan /root/backup/trojan',
                'cp -r /etc/vless /root/backup/vless',
                'cp -r /etc/slowdns /root/backup/',
                'cp -r /etc/xray /root/backup/xray',
                'find /var/www/html/ -type f -name "*.html" ! -name "index.html" -exec cp {} /root/backup/html/ \;'
            ]

            for command in backup_commands:
                subprocess.run(command, shell=True)

            IP = requests.get('https://ipinfo.io/ip').text.strip()
            now = datetime.datetime.now()
            date = now.strftime('%Y-%m-%d')
            dates = now.strftime('%d %B %Y')
            time = now.strftime('%H:%M')
            zip_filename = f"{IP}-{date}.zip"
            subprocess.run(f'cd /root && zip -r {zip_filename} backup > /dev/null 2>&1', shell=True)

            upload_command = f'curl -s -X POST -F "reqtype=fileupload" -F "fileToUpload=@/root/{zip_filename}" https://catbox.moe/user/api.php'
            catbox_response = subprocess.getoutput(upload_command)
            catbox_url = catbox_response.strip()

            backup_details = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Backup Server Successfully ⟩**
**◇━━━━━━━━━━━━━━━━◇**
» **IP      :** `{IP}`
» **Link    :** [Download Backup]({catbox_url})
» **Date    :** `{dates}`
» **Time    :** `{time} WIB`
**◇━━━━━━━━━━━━━━━━◇**
"""
            inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
            await msg.edit(f"{backup_details}", buttons=inline)

            cleanup_command = f'rm -rf /root/backup /root/{zip_filename}'
            subprocess.run(cleanup_command, shell=True)

        except Exception as e:
            await event.respond(f"**Failed to backup the server:** {e}")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await server_backup_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'restore-backup'))
async def restore_backup(event):
    async def restore_backup_(event):
        async with bot.conversation(event.chat_id) as user:
            await event.respond("**Enter the Backup File URL:**")
            url_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            url = (await url_event).raw_text

        url_pattern = r'^(https:\/\/(qu\.ax\/[A-Za-z0-9_-]+\.zip|files\.catbox\.moe\/[A-Za-z0-9_-]+\.zip))$'
        if not re.match(url_pattern, url):
            inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
            await event.respond("**Invalid or unsupported URL!**`", buttons=inline)
            return

        try:
            msg = await event.respond("**Downloading Backup...**")
            subprocess.run(f"wget -O backup.zip \"{url}\"", shell=True)
            subprocess.run("unzip backup.zip", shell=True)
            subprocess.run("rm -rf backup.zip", shell=True)
            await msg.edit("**Restoring the Backup...**")
            await asyncio.sleep(3)
            subprocess.run("cp /root/backup/passwd /etc/", shell=True)
            subprocess.run("cp /root/backup/group /etc/", shell=True)
            subprocess.run("cp /root/backup/shadow /etc/", shell=True)
            subprocess.run("cp /root/backup/gshadow /etc/", shell=True)
            subprocess.run("cp /root/backup/crontab /etc/", shell=True)
            subprocess.run("cp /root/backup/.vmess.db /etc/vmess/", shell=True)
            subprocess.run("cp /root/backup/.vless.db /etc/vless/", shell=True)
            subprocess.run("cp /root/backup/.trojan.db /etc/trojan/", shell=True)
            subprocess.run("cp /root/backup/.ssh.db /etc/ssh/", shell=True)
            subprocess.run("cp /root/backup/.bot.db /etc/bot/", shell=True)
            subprocess.run("cp -r /root/backup/xray /etc/", shell=True)
            subprocess.run("cp -r /root/backup/slowdns /etc/", shell=True)
            subprocess.run("cp -r /root/backup/limit /etc/rs/", shell=True)
            subprocess.run("cp -r /root/backup/vmess /etc/", shell=True)
            subprocess.run("cp -r /root/backup/trojan /etc/", shell=True)
            subprocess.run("cp -r /root/backup/vless /etc/", shell=True)
            subprocess.run("cp -r /root/backup/html /var/www/", shell=True)

            subprocess.run("rm -r /root/backup", shell=True)
            subprocess.run("systemctl restart ws > /dev/null 2>&1", shell=True)
            subprocess.run("systemctl restart xray > /dev/null 2>&1", shell=True)
            subprocess.run("systemctl restart cron > /dev/null 2>&1", shell=True)
            inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
            await msg.edit("**Restored Backup Successfully!**", buttons=inline)

        except Exception as e:
            inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
            await event.respond(f"**Failed to restore the backup:** {e}", buttons=inline)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await restore_backup_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'restart-services'))
async def restart_services(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        inline_buttons = [
            [Button.inline("Yes", b'confirm_restart_services_yes'), Button.inline("No", b'confirm_restart_services_no')]
        ]
        await event.respond("**Confirm Restart All Services?**", buttons=inline_buttons)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'confirm_restart_services_yes'))
async def confirm_restart_services_yes(event):
    try:
        inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
        await event.edit("**Restarting All Services... Please wait...**", buttons=None)
        
        services = [
            "systemctl daemon-reload",
            "systemctl restart nginx",
            "systemctl restart ssh",
            "systemctl restart ws",
            "systemctl restart xray",
            "systemctl restart cron",
            "systemctl restart squid",
            "systemctl restart vnstat",
            "systemctl restart fail2ban",
            "systemctl restart haproxy",
            "systemctl restart openvpn",
            "systemctl restart dropbear",
            "systemctl restart udp-custom"
        ]
        
        for service in services:
            subprocess.Popen(service, shell=True)
            await asyncio.sleep(1)
        
        await event.edit("**All Services Restarted Successfully!**", buttons=inline)
    except Exception as e:
        await event.respond(f"**Failed to restart services:** {e}")

@bot.on(events.CallbackQuery(data=b'confirm_restart_services_no'))
async def confirm_restart_services_no(event):
    inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
    await event.edit("**Restart Services Canceled!**", buttons=inline)
    
@bot.on(events.CallbackQuery(data=b'running-services'))
async def running_services(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        services = [
            "ws", "ssh", "xray", "cron", "nginx",
            "squid", "vnstat", "fail2ban", "haproxy", 
            "openvpn", "dropbear", "udp-custom"
        ]
        
        status_messages = []
        for service in services:
            try:
                result = subprocess.run(
                    f"systemctl is-active {service}", 
                    shell=True, 
                    capture_output=True, 
                    text=True
                )
                status = result.stdout.strip()
                status_emoji = "🟢" if status == "active" else "🔴"
                status_messages.append(f"**» {service.upper()}:** `{status}` {status_emoji}")
            except Exception:
                status_messages.append(f"**» {service.upper()}:** `Unknown` 🔴")
        
        status_text = "\n".join(status_messages)
        inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
        
        message = f"""
**◇━━━━━━━━━━━━━━━━◇**
**  ⟨ Check Running Services ⟩**
**◇━━━━━━━━━━━━━━━━◇**
{status_text}
**◇━━━━━━━━━━━━━━━━◇**
"""
        
        await event.edit(message, buttons=inline)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'speedtest-server'))
async def speedtest(event):
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        msg = await event.respond("**Testing Speedtest...**")
        async with bot.conversation(event.chat) as user:
            try:
                await asyncio.sleep(1)
                process = await asyncio.create_subprocess_shell(
                    'speedtest --accept-license',
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout, stderr = await process.communicate()
                output = stdout.decode('utf-8')
                
                lines = output.split('\n')
                server_line = next((line for line in lines if 'Server:' in line), None)
                isp_line = next((line for line in lines if 'ISP:' in line), None)
                latency_line = next((line for line in lines if 'Latency:' in line), None)
                download_line = next((line for line in lines if 'Download:' in line), None)
                upload_line = next((line for line in lines if 'Upload:' in line), None)
                packet_loss_line = next((line for line in lines if 'Packet Loss:' in line), None)
                result_url_line = next((line for line in lines if 'Result URL:' in line), None)
                
                result_msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Speedtest Server Results ⟩**
**◇━━━━━━━━━━━━━━━━◇**
{server_line and server_line.strip().replace('Server:', '» **Server:**')}
{isp_line and isp_line.strip().replace('ISP:', '» **ISP:**')}
{latency_line and latency_line.strip().replace('Latency:', '» **Latency:**')}
{download_line and download_line.strip().replace('Download:', '» **Download:**')}
{upload_line and upload_line.strip().replace('Upload:', '» **Upload:**')}
{packet_loss_line and packet_loss_line.strip().replace('Packet Loss:', '» **Packet Loss:**')}
{result_url_line and result_url_line.strip().replace('Result URL:', '» **Result URL:**')}
**◇━━━━━━━━━━━━━━━━◇**
"""

                
                inline = [[Button.inline("‹ Back Menu ›", "menu-setting")]]
                await msg.edit(result_msg, buttons=inline)
            except Exception as e:
                await msg.edit(f"**Failed testing speedtest:** {str(e)}")
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'change-banner'))
async def change_banner(event):
    async def change_banner_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Send the new banner SSH:**")
            response = await user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            new_banner = response.raw_text
            await event.respond(f"**New Banner SSH Received:**\n\n```{new_banner}```\n\n**Confirm Updated Banner SSH?**", 
                buttons=[
                    [Button.inline("Yes", b'confirm_update_banner_yes'), Button.inline("No", b'confirm_update_banner_no')]
                ]
            )
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await change_banner_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'confirm_update_banner_yes'))
async def confirm_update_banner_yes(event):
    try:
        message = await event.get_message()
        new_banner = message.text.split("```")[1]
        with open('/etc/issue.net', 'w') as f:
            f.write(new_banner)
        await event.edit("**Banner SSH Updated Successfully!**", 
            buttons=[[Button.inline("‹ Back Menu ›", b"menu-setting")]]
        )
        await asyncio.sleep(1)
        subprocess.Popen("systemctl restart dropbear", shell=True)
    except Exception as e:
        await event.edit(f"**Failed to update banner SSH: {e}**", 
            buttons=[[Button.inline("‹ Back Menu ›", b"menu-setting")]]
        )

@bot.on(events.CallbackQuery(data=b'confirm_update_banner_no'))
async def confirm_update_banner_no(event):
    await event.edit("**Banner SSH Updated Canceled!**", 
        buttons=[[Button.inline("‹ Back Menu ›", b"menu-setting")]]
    )
    