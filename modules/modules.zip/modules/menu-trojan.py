#!/usr/bin/env python3

import requests
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'menu-trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("[ ᴄʀᴇᴀᴛᴇ ᴛʀᴏᴊᴀɴ ]", b'create-trojan'),
             Button.inline("[ ᴛʀɪᴀʟ ᴛʀᴏᴊᴀɴ ]", b'trial-trojan')],
            [Button.inline("[ ᴅᴇʟᴇᴛᴇ ᴛʀᴏᴊᴀɴ ]", b'delete-trojan'),
             Button.inline("[ ʀᴇɴᴇᴡ ᴛʀᴏᴊᴀɴ ]", b'renew-trojan')],
            [Button.inline("[ ʟᴏᴄᴋᴇᴅ ᴛʀᴏᴊᴀɴ ]", b'lock-trojan'),
             Button.inline("[ ᴜɴʟᴏᴄᴋ ᴛʀᴏᴊᴀɴ ]", b'unlock-trojan')],
            [Button.inline("[ sʜᴏᴡ ᴜsᴇʀ ᴛʀᴏᴊᴀɴ ]", b'show-trojan'),
             Button.inline("[ ᴄʜᴇᴄᴋ ᴄᴏɴꜰɪɢ ᴛʀᴏᴊᴀɴ ]", b'check-trojan')],
            [Button.inline("‹ Main Menu ›", b'menu-manager')]
        ]
            
        try:
            cmd = "grep -c -E \"^#! \" \"/etc/xray/config.json\" || echo 0"
            trx = int(subprocess.check_output(cmd, shell=True))
            trb = trx // 2
        except subprocess.CalledProcessError:
            trb = 0
        except Exception:
            trb = 0
            
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "Unknown")
            city = z.get("city", "Unknown")
        except Exception:
            isp = "Unknown"
            city = "Unknown"
            
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**    ⟨ Menu TROJAN Manager ⟩     **
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» ISP:** `{isp}`
**» City:** `{city}`
**» Total TROJAN:** `{trb}` Accounts
**◇━━━━━━━━━━━━━━━━◇**
**» Bot By:** @RidwanzSaputra\n
"""
        await event.edit(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trojan_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        