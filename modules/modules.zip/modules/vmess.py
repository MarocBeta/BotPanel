#!/usr/bin/env python3

import os
import json
import base64
import asyncio
import random
import requests
import subprocess
import datetime as DT
from BotPanel import *

async def loading(bot, chat_id, message_id):
    progress_bar_length = 10
    for i in range(progress_bar_length + 1):
        percentage = i * 10
        progress = f"[{'■' * i}{'□' * (progress_bar_length - i)}] {percentage}%"
        await bot.edit_message(chat_id, message_id, f"**{progress}**")
        await asyncio.sleep(0.8)
    await bot.edit_message(chat_id, message_id, "**ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ...**")
    await asyncio.sleep(1)
    await bot.delete_messages(chat_id, message_id)

@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    async def create_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as user_conv:
            await event.respond('**Enter Username:**')
            user = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.strip()
 
        uuid = subprocess.check_output('cat /proc/sys/kernel/random/uuid', shell=True).decode().strip()
        bug = "Enter_your_bug"
        domain = DOMAIN

        quota = ''
        async with bot.conversation(chat) as quota_conv:
            await event.respond("**Enter Limit Quota (GB):**")
            quota_msg = quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = (await quota_msg).raw_text.strip()
            if not quota.isdigit() and quota != '':
                invalid_msg = await event.respond("**Please enter a valid number!**")
                await asyncio.sleep(2)
                await invalid_msg.delete()
                quota = '0'

        iplimit = ''
        while not iplimit.isdigit():
            async with bot.conversation(chat) as iplimit_conv:
                await event.respond("**Enter Limit IP:**")
                iplimit = iplimit_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplimit = (await iplimit).raw_text.strip()
                if not iplimit.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()

        exp = ''
        while not exp.isdigit():
            await event.respond("**Enter Expired Days:**")
            async with bot.conversation(chat) as exp_conv:
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text.strip()
                if not exp.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue
                break
                
        try:
            check_user = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
        except Exception as e:
            check_user = "0"
        if check_user != "0":
            await event.respond(f"**User `{user}` Already Exists!**")
            return
            
        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)
            
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        expired = later.strftime("%Y-%m-%d")
        
        cmd1 = f"sed -i '/#vmess$/a\\### {user} {expired}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json"
        cmd2 = f"sed -i '/#vmessgrpc$/a\\### {user} {expired}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json"
        
        os.system(cmd1)
        os.system(cmd2)

        tls = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        none = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "80",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "none"
        }
        
        grpc = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "grpc",
            "path": "vmess-grpc",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        vmesslink1 = "vmess://" + base64.b64encode(json.dumps(tls).encode()).decode()
        vmesslink2 = "vmess://" + base64.b64encode(json.dumps(none).encode()).decode()
        vmesslink3 = "vmess://" + base64.b64encode(json.dumps(grpc).encode()).decode()
        
        os.makedirs("/etc/vmess", exist_ok=True)
        
        if int(iplimit) > 0:
            os.makedirs("/etc/rs/limit/vmess/ip", exist_ok=True)
            with open(f"/etc/rs/limit/vmess/ip/{user}", "w") as f:
                f.write(iplimit)
        
        if quota != '0':
            quota_bytes = int(quota) * 1024 * 1024 * 1024
            with open(f"/etc/vmess/{user}", "w") as f:
                f.write(str(quota_bytes))
        
        os.makedirs("/etc/vmess", exist_ok=True)
        
        try:
            with open("/etc/vmess/.vmess.db", "r") as db_file:
                db_contents = db_file.read()
        except FileNotFoundError:
            db_contents = ""
        
        if f"### {user}" in db_contents:
            os.system(f"sed -i \"/\\b{user}\\b/d\" /etc/vmess/.vmess.db")
        
        with open("/etc/vmess/.vmess.db", "a") as db_file:
            db_file.write(f"### {user} {expired} {uuid} {quota} {iplimit}\n")
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        IP = requests.get('https://ipinfo.io/ip').text.strip()
        
        delete_account = f"""
cat > /tmp/delete_vmess_{user}.sh << EOF
#!/bin/bash
sed -i "/^### {user} {expired}/,/^}},{{/d" /etc/xray/config.json
sed -i "/^### {user} {expired}/,/^###/d" /etc/vmess/.vmess.db
rm -rf /etc/vmess/{user}
rm -rf /etc/rs/limit/vmess/ip/{user}
rm -rf /var/www/html/vmess-{user}.html
systemctl restart xray > /dev/null 2>&1
rm -rf /tmp/delete_vmess_{user}.sh
EOF
chmod +x /tmp/delete_vmess_{user}.sh
echo "/tmp/delete_vmess_{user}.sh" | at now + {exp} days
"""
        os.system(delete_account)
        os.system("systemctl restart xray")
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Created VMESS Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {z['isp']}
**» CITY:** {z['city']}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{domain}`
**» Remarks:** `{user}`
**» UUID:** `{uuid}`
**» AlterId:** `0`
**» Cipher:** `auto`
**» Path:** `/vmess`
**» Path GRPC:** `vmess-grpc`
**» Limit IP:** `{iplimit}` Devices
**» Limit Quota:** `{quota} GB`
**◇━━━━━━━━━━━━━━━━◇**
**» Port TLS:** `443`
**» Port NTLS:** `80`
**» Port GRPC:** `443`
**◇━━━━━━━━━━━━━━━━◇**
**» Link TLS:**
`{vmesslink1}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link NTLS:**
`{vmesslink2}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link GRPC:**
`{vmesslink3}`
**◇━━━━━━━━━━━━━━━━◇**
**» Save Link Account:**
`https://{domain}:81/vmess-{user}.html`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expired}`
**» 🗓Expired Until:** `{exp}` Days
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(msg, buttons=inline)
        
        html_content = f"""
<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VMESS Account - {user}</title>
    <style>
    
        :root {{
            --primary-color: #7c4dff;
            --secondary-color: #3f2b96;
            --bg-color: #121212;
            --text-color: #ffffff;
            --border-color: #2d4059;
            --card-bg: #1e1e1e;
            --highlight: #b388ff;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }}
        
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }}
        
        .LwDfoPtnIshJfhY {{
            width: 100%;
            max-width: 800px;
            margin: 20px auto;
            padding: 15px;
        }}
        
        .bXMTiZjQaTzYfhd {{
            background-color: var(--card-bg);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            margin-bottom: 25px;
        }}
        
        .vEKBZbqSEoEELHA {{
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .QpTRSWlvWObRbMk {{
            padding: 20px;
        }}
        
        .ugKbgnRdpGJqzkv {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .fFlebbdONFYVnOx {{
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 15px;
            align-items: center;
        }}
        
        .UFJAknFeRQYhvpy {{
            font-weight: bold;
            width: 140px;
            color: var(--highlight);
            flex-shrink: 0;
        }}
        
        .KXuAzibdYHZWdTt {{
            flex: 1;
            min-width: 0;
            word-break: break-word;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .SOomMzvZlPFErGP, .HaijokxowNCkjtx {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .qdMZpIPfYelLTpu {{
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 18px;
        }}
        
        .DttptuUjzeSuQgc {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            overflow-x: auto;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--primary-color);
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .DttptuUjzeSuQgc span {{
            margin-right: 10px;
            word-break: break-all;
            max-width: calc(100% - 70px);
        }}
        
        .mShKHlqqSViFOrR {{
            margin-top: 20px;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.2);
            padding: 15px;
        }}
        
        .aQZBrZNBIKKkYmP {{
            margin-bottom: 15px;
            color: var(--highlight);
            font-weight: bold;
        }}
        
        .IePLXJYhkEXVqWj {{
            margin-bottom: 15px;
        }}
        
        .oCnxSCzSLNkfewv {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            white-space: pre-wrap;
            overflow-x: auto;
            margin-bottom: 15px;
            position: relative;
        }}
        
        .oCnxSCzSLNkfewv button {{
            position: absolute;
            top: 10px;
            right: 10px;
        }}
        
        .DHDWTgWWGrOeqVP {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            background-color: rgba(124, 77, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            gap: 10px;
        }}
        
        .KaaPDuZuamkhITk {{
            font-weight: bold;
            color: var(--highlight);
        }}
        
        .OTdoZAuMSPGHHbP {{
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s;
            flex-shrink: 0;
            white-space: nowrap;
        }}
        
        .copy-btn:hover {{
            background-color: var(--secondary-color);
        }}
        
        .AcvlvWBlXILqfdQ {{
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            color: #999;
            font-size: 14px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        
        @media (max-width: 600px) {{
            .fFlebbdONFYVnOx {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .UFJAknFeRQYhvpy {{
                margin-bottom: 5px;
            }}
            
            .KXuAzibdYHZWdTt {{
                width: 100%;
                margin-bottom: 5px;
                justify-content: space-between;
            }}
            
            .OTdoZAuMSPGHHbP {{
                margin-left: auto;
            }}
            
            .DHDWTgWWGrOeqVP {{
                flex-direction: column;
                align-items: flex-start;
            }}
        }}
    </style>
    
    <script>
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('Copied to clipboard!');
                
            }}).catch(err => {{
                console.error('Failed to copy: ', err);
            }});
        }}
        
        document.addEventListener('DOMContentLoaded', function() {{
            document.getElementById('year').textContent = new Date().getFullYear();
        }});
    </script>
    
</head>

<body>
    <div class="LwDfoPtnIshJfhY">
        <div class="bXMTiZjQaTzYfhd">
        
            <div class="vEKBZbqSEoEELHA">
                VMESS Account Information
            </div>
            
            <div class="QpTRSWlvWObRbMk">
                <div class="ugKbgnRdpGJqzkv">
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Host/IP:</div>
                        <div class="KXuAzibdYHZWdTt">{domain} / {IP}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">ISP/Location:</div>
                       <div class="KXuAzibdYHZWdTt">{z.get("isp")} / {z.get("city")}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Remarks:</div>
                        <div class="KXuAzibdYHZWdTt">{user} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{user}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">UUID:</div>
                        <div class="KXuAzibdYHZWdTt">{uuid} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{uuid}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Device Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{iplimit} devices</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Quota Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{quota} GB</div>
                    </div>
                </div>
                
                <div class="SOomMzvZlPFErGP">
                    <div class="qdMZpIPfYelLTpu">Connection Details</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Path:</div>
                        <div class="KXuAzibdYHZWdTt">/vmess</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Path GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">vmess-grpc</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port TLS:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port NTLS:</div>
                        <div class="KXuAzibdYHZWdTt">80</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                </div>
                
                <div class="HaijokxowNCkjtx">
                    <div class="qdMZpIPfYelLTpu">Connection Links</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">VMESS TLS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink1} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink1}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">VMESS NTLS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink2} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink2}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">VMESS GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink3} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink3}')">Copy</button></div>
                        </div>
                    </div>
                </div>
                
                <div class="mShKHlqqSViFOrR">
                    <div class="aQZBrZNBIKKkYmP">Clash Configuration</div>
                    <div class="IePLXJYhkEXVqWj">
                    
                        <div class="qdMZpIPfYelLTpu">VMESS TLS</div>
                        <div class="oCnxSCzSLNkfewv">-   
  server: {bug}
  type: vmess
  port: 443
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: {domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: {domain}
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                        
                        <div class="qdMZpIPfYelLTpu">VMESS NTLS</div>
                        <div class="oCnxSCzSLNkfewv">- name: {user}
  server: {bug}
  type: vmess
  port: 80
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: false
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: {domain}
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                        
                        <div class="qdMZpIPfYelLTpu">VMESS GRPC</div>
                        <div class="oCnxSCzSLNkfewv">- name: {user}
  server: {bug}
  type: vmess
  port: 443
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: {domain}
  network: grpc
  grpc-opts:
    grpc-service-name: vmess-grpc
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                    </div>
                </div>
                
                <div class="DHDWTgWWGrOeqVP">
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Expired:</span> {expired}
                    </div>
                    
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Duration:</span> {exp} Days
                    </div>
                </div>
            </div>
        </div>
        
        <div class="AcvlvWBlXILqfdQ">
            <p>© <span id="year"></span> RidwanzVPN. All Rights Reserved.</p>
        </div>
        
    </div>

</body></html>
"""
        
        file_path = f"/var/www/html/vmess-{user}.html"
        with open(file_path, 'w') as f:
            f.write(html_content)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-vmess'))
async def renew_vmess(event):
    async def renew_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Enter Username:**')
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_user = subprocess.check_output(f"grep -wc '### {user}' '/etc/xray/config.json'", shell=True).decode().strip()
        except Exception as e:
            check_user = "0"
            
        if check_user == "0":
            inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
            await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
        
        uuid = subprocess.check_output(f"grep -A 2 '### {user} ' /etc/xray/config.json | grep -oP '\"id\": \"\\K[^\"]+' | head -n 1", shell=True).decode().strip()
        
        subprocess.check_output(f"rm -rf /etc/rs/limit/vmess/ip/{user}", shell=True)
        subprocess.check_output(f"rm -rf /etc/vmess/{user}", shell=True)
            
        async with bot.conversation(chat) as quota_conv:
            await event.respond('**Enter Limit Quota (GB):**')
            quota_event = quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await quota_event).raw_text.strip()
            if not Quota.isdigit() and Quota != '':
                await event.respond("**Please enter a valid number!**")
                Quota = "0"
        
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Enter Limit IP:**')
            ip_event = ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            iplimit = (await ip_event).raw_text.strip()
            if not iplimit.isdigit():
                await event.respond("**Please enter a valid number!**")
                return
                
        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Enter Expired Days:**')
            exp_event = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            expired = (await exp_event).raw_text.strip()
            if not expired.isdigit():
                await event.respond("**Please enter a valid number!**")
                return
        
        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)
        
        exp = subprocess.check_output(f"grep -wE '^### {user}' '/etc/xray/config.json' | cut -d ' ' -f 3 | sort | uniq", shell=True).decode().strip()
        
        subprocess.check_output("mkdir -p /etc/rs/limit/vmess/ip", shell=True)
        with open(f"/etc/rs/limit/vmess/ip/{user}", "w") as f:
            f.write(iplimit)
        
        subprocess.check_output("mkdir -p /etc/vmess/", shell=True)
        if Quota != "0":
            c = int(Quota)
            d = c * 1024 * 1024 * 1024
            with open(f"/etc/vmess/{user}", "w") as f:
                f.write(str(d))
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(expired))
        expiry = later.strftime("%Y-%m-%d")        
        
        subprocess.check_output(f"sed -i '/### {user}/c\\### {user} {expiry}' /etc/xray/config.json", shell=True)
        subprocess.check_output(f"sed -i '/### {user}/c\\### {user} {expiry} {uuid} {Quota} {iplimit}' /etc/vmess/.vmess.db", shell=True)
        subprocess.check_output(f"rm -rf /tmp/delete_vmess_{user}.sh", shell=True)
        
        delete_account = f"""
cat > /tmp/delete_vmess_{user}.sh << EOF
#!/bin/bash
sed -i "/^### {user} {expired}/,/^}},{{/d" /etc/xray/config.json
sed -i "/^### {user} {expired}/,/^###/d" /etc/vmess/.vmess.db
rm -rf /etc/vmess/{user}
rm -rf /etc/rs/limit/vmess/ip/{user}
rm -rf /var/www/html/vmess-{user}.html
systemctl restart xray > /dev/null 2>&1
rm -rf /tmp/delete_vmess_{user}.sh
EOF
chmod +x /tmp/delete_vmess_{user}.sh
echo "/tmp/delete_vmess_{user}.sh" | at now + {expired} days
"""
        os.system(delete_account)
        os.system("systemctl restart xray")
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Renewed VMESS Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» Remarks:** `{user.strip()}`
**» Limit IP:** `{iplimit} Devices`
**» Limit Quota:** `{Quota} GB`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expiry}`
**» 🗓Expired Until:** `{expired}` Days
**◇━━━━━━━━━━━━━━━━◇**
"""
        
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(msg, buttons=inline)
        
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await renew_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        exp = ''
        while not exp.isdigit() or int(exp) > 60:
            await event.respond("**Enter Expired Minutes:**")
            async with bot.conversation(chat) as exp_conv:
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text.strip()
                if not exp.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue
                
                if int(exp) > 60:
                    invalid_msg = await event.respond("**Maximum trial is 60 minutes!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue
                
                break
        uuid = subprocess.check_output('cat /proc/sys/kernel/random/uuid', shell=True).decode().strip()
        bug = "Enter_your_bug"
        domain = DOMAIN
        user = "Trial-VMESS" + str(random.randint(10000, 99999))
        iplimit = '100'
        quota = '100'
        
        try:
            check_user = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
        except Exception as e:
            check_user = "0"
        if check_user != "0":
            await event.respond(f"**User `{user}` Already Exists!**")
            return
            
        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)      
           
        today = DT.date.today()
        later = today + DT.timedelta(days=0)
        expired = later.strftime("%Y-%m-%d")
        
        today = DT.datetime.now()
        later = today + DT.timedelta(minutes=int(exp))
        expiredMinutes = later.strftime("%B %d, %Y at %H:%M WIB")
        
        cmd1 = f"sed -i '/#vmess$/a\\### {user} {expired}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json"
        cmd2 = f"sed -i '/#vmessgrpc$/a\\### {user} {expired}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json"
        
        os.system(cmd1)
        os.system(cmd2)
        tls = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        none = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "80",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "none"
        }
        
        grpc = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "grpc",
            "path": "vmess-grpc",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        vmesslink1 = "vmess://" + base64.b64encode(json.dumps(tls).encode()).decode()
        vmesslink2 = "vmess://" + base64.b64encode(json.dumps(none).encode()).decode()
        vmesslink3 = "vmess://" + base64.b64encode(json.dumps(grpc).encode()).decode()
        
        os.makedirs("/etc/vmess", exist_ok=True)
        
        if int(iplimit) > 0:
            os.makedirs("/etc/rs/limit/vmess/ip", exist_ok=True)
            with open(f"/etc/rs/limit/vmess/ip/{user}", "w") as f:
                f.write(iplimit)
        
        if quota != '0':
            quota_bytes = int(quota) * 1024 * 1024 * 1024
            with open(f"/etc/vmess/{user}", "w") as f:
                f.write(str(quota_bytes))
        
        with open("/etc/vmess/.vmess.db", "a") as db_file:
            db_file.write(f"### {user} {expired} {uuid} {quota} {iplimit}\n")
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        IP = requests.get('https://ipinfo.io/ip').text.strip()
        
        delete_triall = f"""
cat > /tmp/delete_vmess_{user}.sh << EOF
#!/bin/bash
sed -i "/^### {user} {expired}/,/^}},{{/d" /etc/xray/config.json
sed -i "/^### {user} {expired}/,/^###/d" /etc/vmess/.vmess.db
rm -rf /etc/vmess/{user}
rm -rf /etc/rs/limit/vmess/ip/{user}
rm -rf /var/www/html/vmess-{user}.html
systemctl restart xray > /dev/null 2>&1
rm -rf /tmp/delete_vmess_{user}.sh
EOF
chmod +x /tmp/delete_vmess_{user}.sh
echo "/tmp/delete_vmess_{user}.sh" | at now + {exp} minutes
"""
        os.system(delete_triall)
        os.system("systemctl restart xray")
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Trial VMESS Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {z['isp']}
**» CITY:** {z['city']}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{domain}`
**» Remarks:** `{user}`
**» UUID:** `{uuid}`
**» AlterId:** `0`
**» Cipher:** `auto`
**» Path:** `/vmess`
**» Path GRPC:** `vmess-grpc`
**» Limit IP:** `{iplimit}` Devices
**» Limit Quota:** `{quota} GB`
**◇━━━━━━━━━━━━━━━━◇**
**» Port TLS:** `443`
**» Port NTLS:** `80`
**» Port GRPC:** `443`
**◇━━━━━━━━━━━━━━━━◇**
**» Link TLS:**
`{vmesslink1}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link NTLS:**
`{vmesslink2}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link GRPC:**
`{vmesslink3}`
**◇━━━━━━━━━━━━━━━━◇**
**» Save Link Account:**
`https://{domain}:81/vmess-{user}.html`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expiredMinutes}`
**» 🗓Expired Until:** `{exp}` Minutes
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(msg, buttons=inline)
        
        html_content = f"""
<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>VMESS Account - {user}</title>
    <style>
    
        :root {{
            --primary-color: #7c4dff;
            --secondary-color: #3f2b96;
            --bg-color: #121212;
            --text-color: #ffffff;
            --border-color: #2d4059;
            --card-bg: #1e1e1e;
            --highlight: #b388ff;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }}
        
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }}
        
        .LwDfoPtnIshJfhY {{
            width: 100%;
            max-width: 800px;
            margin: 20px auto;
            padding: 15px;
        }}
        
        .bXMTiZjQaTzYfhd {{
            background-color: var(--card-bg);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            margin-bottom: 25px;
        }}
        
        .vEKBZbqSEoEELHA {{
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .QpTRSWlvWObRbMk {{
            padding: 20px;
        }}
        
        .ugKbgnRdpGJqzkv {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .fFlebbdONFYVnOx {{
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 15px;
            align-items: center;
        }}
        
        .UFJAknFeRQYhvpy {{
            font-weight: bold;
            width: 140px;
            color: var(--highlight);
            flex-shrink: 0;
        }}
        
        .KXuAzibdYHZWdTt {{
            flex: 1;
            min-width: 0;
            word-break: break-word;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .SOomMzvZlPFErGP, .HaijokxowNCkjtx {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .qdMZpIPfYelLTpu {{
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 18px;
        }}
        
        .DttptuUjzeSuQgc {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            overflow-x: auto;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--primary-color);
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .DttptuUjzeSuQgc span {{
            margin-right: 10px;
            word-break: break-all;
            max-width: calc(100% - 70px);
        }}
        
        .mShKHlqqSViFOrR {{
            margin-top: 20px;
            border-radius: 5px;
            background-color: rgba(0, 0, 0, 0.2);
            padding: 15px;
        }}
        
        .aQZBrZNBIKKkYmP {{
            margin-bottom: 15px;
            color: var(--highlight);
            font-weight: bold;
        }}
        
        .IePLXJYhkEXVqWj {{
            margin-bottom: 15px;
        }}
        
        .oCnxSCzSLNkfewv {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            white-space: pre-wrap;
            overflow-x: auto;
            margin-bottom: 15px;
            position: relative;
        }}
        
        .oCnxSCzSLNkfewv button {{
            position: absolute;
            top: 10px;
            right: 10px;
        }}
        
        .DHDWTgWWGrOeqVP {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            background-color: rgba(124, 77, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            gap: 10px;
        }}
        
        .KaaPDuZuamkhITk {{
            font-weight: bold;
            color: var(--highlight);
        }}
        
        .OTdoZAuMSPGHHbP {{
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s;
            flex-shrink: 0;
            white-space: nowrap;
        }}
        
        .copy-btn:hover {{
            background-color: var(--secondary-color);
        }}
        
        .AcvlvWBlXILqfdQ {{
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            color: #999;
            font-size: 14px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        
        @media (max-width: 600px) {{
            .fFlebbdONFYVnOx {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .UFJAknFeRQYhvpy {{
                margin-bottom: 5px;
            }}
            
            .KXuAzibdYHZWdTt {{
                width: 100%;
                margin-bottom: 5px;
                justify-content: space-between;
            }}
            
            .OTdoZAuMSPGHHbP {{
                margin-left: auto;
            }}
            
            .DHDWTgWWGrOeqVP {{
                flex-direction: column;
                align-items: flex-start;
            }}
        }}
    </style>
    
    <script>
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('Copied to clipboard!');
                
            }}).catch(err => {{
                console.error('Failed to copy: ', err);
            }});
        }}
        
        document.addEventListener('DOMContentLoaded', function() {{
            document.getElementById('year').textContent = new Date().getFullYear();
        }});
    </script>
    
</head>

<body>
    <div class="LwDfoPtnIshJfhY">
        <div class="bXMTiZjQaTzYfhd">
        
            <div class="vEKBZbqSEoEELHA">
                VMESS Account Information
            </div>
            
            <div class="QpTRSWlvWObRbMk">
                <div class="ugKbgnRdpGJqzkv">
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Host/IP:</div>
                        <div class="KXuAzibdYHZWdTt">{domain} / {IP}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">ISP/Location:</div>
                       <div class="KXuAzibdYHZWdTt">{z.get("isp")} / {z.get("city")}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Remarks:</div>
                        <div class="KXuAzibdYHZWdTt">{user} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{user}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">UUID:</div>
                        <div class="KXuAzibdYHZWdTt">{uuid} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{uuid}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Device Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{iplimit} devices</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Quota Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{quota} GB</div>
                    </div>
                </div>
                
                <div class="SOomMzvZlPFErGP">
                    <div class="qdMZpIPfYelLTpu">Connection Details</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Path:</div>
                        <div class="KXuAzibdYHZWdTt">/vmess</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Path GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">vmess-grpc</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port TLS:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port NTLS:</div>
                        <div class="KXuAzibdYHZWdTt">80</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Port GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                </div>
                
                <div class="HaijokxowNCkjtx">
                    <div class="qdMZpIPfYelLTpu">Connection Links</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">VMESS TLS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink1} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink1}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">VMESS NTLS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink2} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink2}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">VMESS GRPC:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{vmesslink3} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{vmesslink3}')">Copy</button></div>
                        </div>
                    </div>
                </div>
                
                <div class="mShKHlqqSViFOrR">
                    <div class="aQZBrZNBIKKkYmP">Clash Configuration</div>
                    <div class="IePLXJYhkEXVqWj">
                    
                        <div class="qdMZpIPfYelLTpu">VMESS TLS</div>
                        <div class="oCnxSCzSLNkfewv">-   
  server: {bug}
  type: vmess
  port: 443
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: {domain}
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: {domain}
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                        
                        <div class="qdMZpIPfYelLTpu">VMESS NTLS</div>
                        <div class="oCnxSCzSLNkfewv">- name: {user}
  server: {bug}
  type: vmess
  port: 80
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: false
  network: ws
  ws-opts:
    path: /vmess
    headers:
      Host: {domain}
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                        
                        <div class="qdMZpIPfYelLTpu">VMESS GRPC</div>
                        <div class="oCnxSCzSLNkfewv">- name: {user}
  server: {bug}
  type: vmess
  port: 443
  uuid: {uuid}
  alterId: 0
  cipher: auto
  tls: true
  skip-cert-verify: true
  servername: {domain}
  network: grpc
  grpc-opts:
    grpc-service-name: vmess-grpc
  udp: true<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard(this.previousSibling.textContent)">Copy</button>
                        </div>
                    </div>
                </div>
                
                <div class="DHDWTgWWGrOeqVP">
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Expired:</span> {expiredMinutes}
                    </div>
                    
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Duration:</span> {exp} Minutes
                    </div>
                </div>
            </div>
        </div>
        
        <div class="AcvlvWBlXILqfdQ">
            <p>© <span id="year"></span> RidwanzVPN. All Rights Reserved.</p>
        </div>
        
    </div>

</body></html>
"""
        
        file_path = f"/var/www/html/vmess-{user}.html"
        with open(file_path, 'w') as f:
            f.write(html_content)
        
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'check-vmess'))
async def check_vmess(event):
    async def check_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_vmess = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
        except Exception as e:
            check_vmess = "0"
            
        if check_vmess == "0":
            inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
            await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
            
        CITY = subprocess.check_output("cat /etc/xray/city", shell=True).decode().strip()
        ISP = subprocess.check_output("cat /etc/xray/isp", shell=True).decode().strip()
        domain = subprocess.check_output("cat /etc/xray/domain", shell=True).decode().strip()
        bug = "Enter_your_bug"
        
        try:
            uuid = subprocess.check_output(f"grep -A 2 '### {user} ' /etc/xray/config.json | grep -oP '\"id\": \"\\K[^\"]+' | head -n 1", shell=True).decode().strip()
            exp = subprocess.check_output(f"grep -wE '^### {user}' /etc/xray/config.json | cut -d ' ' -f 3 | sort | uniq", shell=True).decode().strip()
        except subprocess.CalledProcessError:
            uuid = "Unknown"
            exp = "Unknown"
            
        try:
            user_data = subprocess.check_output(f"grep '{user}' /etc/vmess/.vmess.db", shell=True).decode().strip()
            user_info = user_data.split()
        except subprocess.CalledProcessError:
            user_info = []
        
        if len(user_info) > 4 and user_info[4].isdigit():
            Quota = user_info[4]
        else:
            Quota = "Unknown"
            
        if len(user_info) > 5 and user_info[5].isdigit():
            iplimit = user_info[5]
        else:
            iplimit = "Unknown"
        
        tls = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        none = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "80",
            "id": f"{uuid}",
            "aid": "0",
            "net": "ws",
            "path": "/vmess",
            "type": "none",
            "host": f"{domain}",
            "tls": "none"
        }
        
        grpc = {
            "v": "2",
            "ps": f"{user}",
            "add": f"{bug}",
            "port": "443",
            "id": f"{uuid}",
            "aid": "0",
            "net": "grpc",
            "path": "vmess-grpc",
            "type": "none",
            "host": f"{domain}",
            "tls": "tls"
        }
        
        vmesslink1 = "vmess://" + base64.b64encode(json.dumps(tls).encode()).decode()
        vmesslink2 = "vmess://" + base64.b64encode(json.dumps(none).encode()).decode()
        vmesslink3 = "vmess://" + base64.b64encode(json.dumps(grpc).encode()).decode()
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Check Config VMESS Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {ISP}
**» CITY:** {CITY}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{domain}`
**» Remarks:** `{user}`
**» UUID:** `{uuid}`
**» AlterId:** `0`
**» Cipher:** `auto`
**» Path:** `/vmess`
**» Path GRPC:** `vmess-grpc`
**» Limit IP:** `{iplimit}` Devices
**» Limit Quota:** `{Quota} GB`
**◇━━━━━━━━━━━━━━━━◇**
**» Port TLS:** `443`
**» Port NTLS:** `80`
**» Port GRPC:** `443`
**◇━━━━━━━━━━━━━━━━◇**
**» Link TLS:**
`{vmesslink1}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link NTLS:**
`{vmesslink2}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link GRPC:**
`{vmesslink3}`
**◇━━━━━━━━━━━━━━━━◇**
**» Save Link Account:**
`https://{domain}:81/vmess-{user}.html`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{exp}`
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await check_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)   

@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username To Be Deleted:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_vmess = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
        except Exception as e:
            check_vmess = "0"
            
        if check_vmess == "0":
            inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
            await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
            
        subprocess.check_output(f"sed -i '/^### {user} /d' /etc/vmess/.vmess.db", shell=True)
        subprocess.check_output(f"sed -i '/^### {user} /,/^}},{{/d' /etc/xray/config.json", shell=True)
        subprocess.check_output(f"rm -rf /etc/vmess/{user}", shell=True)
        subprocess.check_output(f"rm -rf /etc/rs/limit/vmess/ip/{user}", shell=True)
        subprocess.check_output(f"rm -rf /tmp/delete_vmess_{user}.sh", shell=True)
        subprocess.check_output(f"rm -rf /var/www/html/vmess-{user}.html", shell=True)
        subprocess.check_output("systemctl restart xray", shell=True)
        
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(f"**User `{user}` Successfully Deleted!**", buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'lock-vmess'))
async def lock_vmess(event):
    async def lock_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username To Be Locked:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_vmess = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
        except:
            check_vmess = "0"
            
        if check_vmess == "0":
            inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
            await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
            
        try:
            uuid = subprocess.check_output(f"grep -A 2 '### {user} ' /etc/xray/config.json | grep -oP '\"id\": \"\\K[^\"]+' | head -n 1", shell=True).decode().strip()
            exp = subprocess.check_output(f"grep -wE '^### {user}' /etc/xray/config.json | cut -d ' ' -f 3 | sort | uniq", shell=True).decode().strip()
            
            try:
                subprocess.check_output("cat /etc/xray/.lock.db", shell=True)
            except:
                subprocess.check_output("touch /etc/xray/.lock.db", shell=True)
            
            try:
                vmess_check = subprocess.check_output("grep -c '#vmess' /etc/xray/.lock.db", shell=True).decode().strip()
                if vmess_check == "0":
                    subprocess.check_output("echo '#vmess' >> /etc/xray/.lock.db", shell=True)
            except:
                subprocess.check_output("echo '#vmess' >> /etc/xray/.lock.db", shell=True)
            
            try:
                lock_entry = f"### {user} {exp} {uuid}"
                
                with open("/etc/xray/.lock.db", "r") as f:
                    content = f.readlines()
                
                new_content = []
                added = False
                
                for line in content:
                    line = line.rstrip()
                    if line.startswith(f"### {user} "):
                        continue
                    new_content.append(line)
                    if line.strip() == "#vmess" and not added:
                        new_content.append(lock_entry)
                        added = True
                
                if not added:
                    for i, line in enumerate(new_content):
                        if line.strip() == "#vmess":
                            new_content.insert(i+1, lock_entry)
                            break
                
                with open("/etc/xray/.lock.db", "w") as f:
                    f.write("\n".join(new_content) + "\n")
            except:
                pass
            
            await asyncio.sleep(0.5)
            
            try:
                subprocess.check_output(f"sed -i '/^### {user} {exp}/,/^}},{{/d' /etc/xray/config.json", shell=True)
            except:
                pass
                
            try:
                subprocess.check_output("systemctl restart xray", shell=True)
            except:
                pass
        except:
            pass
            
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(f"**User `{user}` Successfully Locked!**", buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await lock_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'unlock-vmess'))
async def unlock_vmess(event):
    async def unlock_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username To Be Unlocked:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_vmess = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/.lock.db", shell=True).decode().strip()
        except Exception as e:
            check_vmess = "0"
            
        if check_vmess == "0":
            try:
                check_user = subprocess.check_output(f"grep -c '### {user} ' /etc/xray/config.json", shell=True).decode().strip()
            except Exception as e:
                check_user = "0"
                
            if check_user != "0":
                inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
                await event.respond(f"**User `{user}` Not Locked!**", buttons=inline)
            else:
                inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
                await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
            
        uuid = subprocess.check_output(f"grep -E '^###' /etc/xray/.lock.db | grep -i '{user}' | cut -d ' ' -f 4", shell=True).decode().strip()
        exp = subprocess.check_output(f"grep -E '^###' /etc/xray/.lock.db | grep -i '{user}' | cut -d ' ' -f 3", shell=True).decode().strip()
        
        subprocess.check_output(f"sed -i '/#vmess$/a\\### {user} {exp}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json", shell=True)
        subprocess.check_output(f"sed -i '/#vmessgrpc$/a\\### {user} {exp}\\n}},{{\"id\": \"{uuid}\",\"alterId\": 0,\"email\": \"{user}\"' /etc/xray/config.json", shell=True)
        subprocess.check_output(f"sed -i '/^### {user} {exp} {uuid}/d' /etc/xray/.lock.db", shell=True)
        subprocess.check_output("systemctl restart xray", shell=True)
        
        inline = [[Button.inline("‹ Back Menu ›", "menu-vmess")]]
        await event.respond(f"**User `{user}` Successfully Unlocked!**", buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await unlock_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'show-vmess'))
async def show_vmess(event):
    async def show_vmess_(event):
        try:
            cmd = "grep -c -E \"^### \" \"/etc/xray/config.json\" || echo 0"
            vmc = int(subprocess.check_output(cmd, shell=True))
            vma = vmc // 2
            
            if vmc > 0:
                cmd = "grep -E \"^### \" \"/etc/xray/config.json\" | awk '{print $2}' | sort -u"
                x = subprocess.check_output(cmd, shell=True).decode("ascii").split("\n")
                z = []
                count = 1
                for us in x:
                    if us != "":
                        z.append(f"{count}. `{us}`")
                        count += 1
                zx = "\n".join(z)
                await event.respond(f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Showing All User VMESS ⟩**
**◇━━━━━━━━━━━━━━━━◇**
{zx}
**◇━━━━━━━━━━━━━━━━◇**
**» Total VMESS Accounts:** `{str(len(z))}`
**◇━━━━━━━━━━━━━━━━◇**
""", buttons=[[Button.inline("‹ Back Menu ›", "menu-vmess")]])
        except Exception as e:
            await event.answer("No VMESS Accounts Found!", alert=True)
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await show_vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        