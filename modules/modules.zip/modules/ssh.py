#!/usr/bin/env python3

import os
import asyncio
import random
import requests
import subprocess
import datetime as DT
from BotPanel import *

async def loading(bot, chat_id, message_id):
    progress_bar_length = 10
    for i in range(progress_bar_length + 1):
        percentage = i * 10
        progress = f"[{'■' * i}{'□' * (progress_bar_length - i)}] {percentage}%"
        await bot.edit_message(chat_id, message_id, f"**{progress}**")
        await asyncio.sleep(0.8)
    await bot.edit_message(chat_id, message_id, "**ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ...**")
    await asyncio.sleep(1)
    await bot.delete_messages(chat_id, message_id)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        async with bot.conversation(chat) as user_conv:
            await event.respond('**Enter Username:**')
            user = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.strip()

        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Enter Password:**")
            pw = pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw).raw_text.strip()

        iplimit = ''
        while not iplimit.isdigit():
            async with bot.conversation(chat) as iplimit_conv:
                await event.respond("**Enter Limit IP:**")
                iplimit = iplimit_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplimit = (await iplimit).raw_text.strip()
                if not iplimit.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()

        exp = ''
        while not exp.isdigit():
            await event.respond("**Enter Expired Days:**")
            async with bot.conversation(chat) as exp_conv:
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text.strip()
                if not exp.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue
                break
                
        limit_dir = "/etc/rs/limit/ssh/ip/"
        os.makedirs(limit_dir, exist_ok=True)
        limit_file = os.path.join(limit_dir, user)
        
        with open(limit_file, 'w') as f:
            f.write(iplimit)

        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)        
        
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        expired = later.strftime("%d %B, %Y")

        cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} && echo "userdel -f {user}; rm -rf /var/www/html/ssh-{user}.html; rm -rf /etc/rs/limit/ssh/ip/{user}; sed -i \'/^#ssh# {user}/d\' /etc/ssh/.ssh.db" | at now +{exp} days'
 
        os.makedirs("/etc/ssh", exist_ok=True)

        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond(f"**User** `{user}` **Already Exists!**")
            return
                    
        try:
            with open("/etc/ssh/.ssh.db", "r") as db_file:
                db_contents = db_file.read()
        except FileNotFoundError:
            db_contents = ""
        
        if f"#ssh# {user}" in db_contents:
            os.system(f"sed -i \"/\\b{user}\\b/d\" /etc/ssh/.ssh.db")
        
        with open("/etc/ssh/.ssh.db", "a") as db_file:
            db_file.write(f"#ssh# {user} {pw} {iplimit} {expired}\n")
                 
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        IP = requests.get('https://ipinfo.io/ip').text.strip()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Created SSH Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {z['isp']}
**» CITY:** {z['city']}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit IP:** `{iplimit}` Devices
**◇━━━━━━━━━━━━━━━━◇**
**» OpenSSH:** `22`
**» Dropbear:** `109`
**» SSH WS:** `80`
**» SSH SSL:** `443`
**» SSH UDP:** `1-65535`
**» OVPN TCP:** `1194`
**» OVPN UDP:** `2200`
**» OVPN SSL:** `990`
**» Proxy Squid:** `3128`
**» UDPGW:** `7100-7300`
**◇━━━━━━━━━━━━━━━━◇**
**» SSH WS:**
`{DOMAIN}:80@{user}:{pw}`
**» SSH SSL:**
`{DOMAIN}:443@{user}:{pw}`
**» SSH UDP:**
`{DOMAIN}:1-65535@{user}:{pw}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link OpenVPN:**
`https://{DOMAIN}:81`
**◇━━━━━━━━━━━━━━━━◇**
**» Save Link Account:**
`https://{DOMAIN}:81/ssh-{user}.html`
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Payload Websocket ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expired}`
**» 🗓Expired Until:** `{exp}` Days
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
        await event.respond(msg, buttons=inline)
        
        html_content = f"""
<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SSH Account - {user}</title>
    <style>
    
        :root {{
            --primary-color: #7c4dff;
            --secondary-color: #3f2b96;
            --bg-color: #121212;
            --text-color: #ffffff;
            --border-color: #2d4059;
            --card-bg: #1e1e1e;
            --highlight: #b388ff;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;+
        }}
        
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }}
        
        .LwDfoPtnIshJfhY {{
            width: 100%;
            max-width: 800px;
            margin: 20px auto;
            padding: 15px;
        }}
        
        .bXMTiZjQaTzYfhd {{
            background-color: var(--card-bg);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            margin-bottom: 25px;
        }}
        
        .vEKBZbqSEoEELHA {{
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .QpTRSWlvWObRbMk {{
            padding: 20px;
        }}
        
        .ugKbgnRdpGJqzkv {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .fFlebbdONFYVnOx {{
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 15px;
            align-items: center;
        }}
        
        .UFJAknFeRQYhvpy {{
            font-weight: bold;
            width: 140px;
            color: var(--highlight);
            flex-shrink: 0;
        }}
        
        .KXuAzibdYHZWdTt {{
            flex: 1;
            min-width: 0;
            word-break: break-word;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .SOomMzvZlPFErGP, .HaijokxowNCkjtx {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .qdMZpIPfYelLTpu {{
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 18px;
        }}
        
        .DttptuUjzeSuQgc {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            overflow-x: auto;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--primary-color);
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .DttptuUjzeSuQgc span {{
            margin-right: 10px;
            word-break: break-all;
            max-width: calc(100% - 70px);
        }}
        
        .DpIdAqRNWsRVmNF pre {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
            white-space: pre-wrap;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--highlight);
            position: relative;
        }}
        
        .DHDWTgWWGrOeqVP {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            background-color: rgba(124, 77, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            gap: 10px;
        }}
        
        .KaaPDuZuamkhITk {{
            font-weight: bold;
            color: var(--highlight);
        }}
        
        .OTdoZAuMSPGHHbP {{
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s;
            flex-shrink: 0;
            white-space: nowrap;
        }}
        
        .copy-btn:hover {{
            background-color: var(--secondary-color);
        }}
        
        .AcvlvWBlXILqfdQ {{
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            color: #999;
            font-size: 14px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        
        @media (max-width: 600px) {{
            .fFlebbdONFYVnOx {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .UFJAknFeRQYhvpy {{
                margin-bottom: 5px;
            }}
            
            .KXuAzibdYHZWdTt {{
                width: 100%;
                margin-bottom: 5px;
                justify-content: space-between;
            }}
            
            .OTdoZAuMSPGHHbP {{
                margin-left: auto;
            }}
            
            .DHDWTgWWGrOeqVP {{
                flex-direction: column;
                align-items: flex-start;
            }}
        }}
    </style>
        
    <script>
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('Copied to clipboard!');
                
            }}).catch(err => {{
                console.error('Failed to copy: ', err);
            }});
        }}
        
        document.addEventListener('DOMContentLoaded', function() {{
            document.getElementById('year').textContent = new Date().getFullYear();
        }});
    </script>
    
</head>

<body>
    <div class="LwDfoPtnIshJfhY">
        <div class="bXMTiZjQaTzYfhd">
        
            <div class="vEKBZbqSEoEELHA">
                SSH Account Information
            </div>
            
            <div class="QpTRSWlvWObRbMk">
                <div class="ugKbgnRdpGJqzkv">
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Host/IP:</div>
                        <div class="KXuAzibdYHZWdTt">{DOMAIN} / {IP}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">ISP/Location:</div>
                        <div class="KXuAzibdYHZWdTt">{z.get("isp")} / {z.get("city")}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Username:</div>
                        <div class="KXuAzibdYHZWdTt">{user} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{user}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Password:</div>
                        <div class="KXuAzibdYHZWdTt">{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{pw}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Device Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{iplimit} devices</div>
                    </div>
                </div>
                
                <div class="SOomMzvZlPFErGP">
                    <div class="qdMZpIPfYelLTpu">Connection Ports</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">OpenSSH:</div>
                        <div class="KXuAzibdYHZWdTt">22</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Dropbear:</div>
                        <div class="KXuAzibdYHZWdTt">109</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH WS:</div>
                        <div class="KXuAzibdYHZWdTt">80</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH SSL:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH UDP:</div>
                        <div class="KXuAzibdYHZWdTt">1-65535</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN TCP:</div>
                        <div class="KXuAzibdYHZWdTt">1194</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN UDP:</div>
                        <div class="KXuAzibdYHZWdTt">2200</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN SSL:</div>
                        <div class="KXuAzibdYHZWdTt">990</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Proxy Squid:</div>
                        <div class="KXuAzibdYHZWdTt">3128</div>
                    </div>
                
                   <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">UDPGW:</div>
                        <div class="KXuAzibdYHZWdTt">7100-7300</div>
                    </div>
                </div>
                
                <div class="HaijokxowNCkjtx">
                    <div class="qdMZpIPfYelLTpu">Connection Details</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">SSH WS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:80@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:80@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH SSL:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:443@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:443@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH UDP:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:1-65535@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:1-65535@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OpenVPN:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">https://{DOMAIN}:81 <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('https://{DOMAIN}:81')">Copy</button></div>
                        </div>
                    </div>
                </div>
                
                <div class="DpIdAqRNWsRVmNF">
                    <div class="qdMZpIPfYelLTpu">Websocket Payload</div>
                    <pre>GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]')">Copy</button></pre>
                </div>
                
                <div class="DHDWTgWWGrOeqVP">
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Expired:</span> {expired}
                    </div>
                    
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Duration:</span> {exp} Days
                    </div>
                </div>
            </div>
        </div>
        
        <div class="AcvlvWBlXILqfdQ">
            <p>© <span id="year"></span> RidwanzVPN. All Rights Reserved.</p>
        </div>
        
    </div>

</body></html>
"""
        file_path = f"/var/www/html/ssh-{user}.html"
        with open(file_path, 'w') as f:
            f.write(html_content)

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await create_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
              
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
    async def renew_ssh_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Enter Username:**')
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            subprocess.check_output(f'id {user}', shell=True)
        except subprocess.CalledProcessError:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User** `{user}` **Not Found!**", buttons=inline)
            return

        iplimit = ""
        while not iplimit.isdigit():
            async with bot.conversation(chat) as iplimit_conv:
                await event.respond('**Enter Limit IP:**')
                iplimit_event = iplimit_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                iplimit = (await iplimit_event).raw_text.strip()
                if not iplimit.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()

        exp = ""
        while not exp.isdigit():
            async with bot.conversation(chat) as exp_conv:
                await event.respond("**Enter Expired Days:**")
                exp_event = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_event).raw_text.strip()
                if not exp.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    
        limit_dir = "/etc/rs/limit/ssh/ip/"
        os.makedirs(limit_dir, exist_ok=True)
        limit_file = os.path.join(limit_dir, user.strip())

        with open(limit_file, 'w') as f:
            f.write(iplimit)

        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)        
           
        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        expired = later.strftime("%d %B,%Y")        
        
        password = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | awk '{{print $3}}'", shell=True).decode().strip()
        
        subprocess.check_output(f"sed -i '/#ssh# {user}/c\\#ssh# {user} {password} {iplimit} {expired}' /etc/ssh/.ssh.db", shell=True)
        
        cmd = f'usermod -e `date -d "{exp} days" +"%Y-%m-%d"` {user} && echo "userdel -f {user}; rm -rf /var/www/html/ssh-{user}.html; rm -rf /etc/rs/limit/ssh/ip/{user}; sed -i \'/^#ssh# {user}/d\' /etc/ssh/.ssh.db" | at now +{exp} days'
        subprocess.check_output(cmd, shell=True)
 
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        IP = requests.get('https://ipinfo.io/ip').text.strip()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Renewed SSH Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» Username:** `{user.strip()}`
**» Limit IP:** `{iplimit} Devices`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expired}`
**» 🗓Expired Until:** `{exp}` Days
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
        await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        exp = ''
        while not exp.isdigit() or int(exp) > 60:
            await event.respond("**Enter Expired Minutes:**")
            async with bot.conversation(chat) as exp_conv:
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text.strip()

                if not exp.isdigit():
                    invalid_msg = await event.respond("**Please enter a valid number!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue
                
                if int(exp) > 60:
                    invalid_msg = await event.respond("**Maximum triall is 60 minutes!**")
                    await asyncio.sleep(2)
                    await invalid_msg.delete()
                    continue             
                break

        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        IP = requests.get('https://ipinfo.io/ip').text.strip()
        user = "Trial-SSH" + str(random.randint(10000, 99999))
        pw = "123456"
        iplimit = '100'
        
        limit_dir = "/etc/rs/limit/ssh/ip/"
        os.makedirs(limit_dir, exist_ok=True)
        limit_file = os.path.join(limit_dir, user)
        with open(limit_file, 'w') as f:
            f.write(iplimit)          
                    
        loading_msg = await event.respond("**ʟᴏᴀᴅɪɴɢ...**")
        await asyncio.sleep(0.5)
        await loading(bot, chat, loading_msg.id)
            
        cmd = f'useradd -e `date -d "{exp} minutes" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} && echo "userdel -f {user}; rm -rf /var/www/html/ssh-{user}.html; rm -rf /etc/rs/limit/ssh/ip/{user}" | at now +{exp} minutes'

        try:
            subprocess.check_output(cmd, shell=True)
        except subprocess.CalledProcessError:
            await event.respond(f"**User** `{user}` **Already Exist!**")
        else:
            today = DT.datetime.now()
            later = today + DT.timedelta(minutes=int(exp))
            expiredMinutes = later.strftime("%B %d, %Y at %H:%M WIB")
            
            msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Success Trial SSH Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {z['isp']}
**» CITY:** {z['city']}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user.strip()}`
**» Password:** `{pw.strip()}`
**» Limit IP:** `{iplimit}` Devices
**◇━━━━━━━━━━━━━━━━◇**
**» OpenSSH:** `22`
**» Dropbear:** `109`
**» SSH WS:** `80`
**» SSH SSL:** `443`
**» SSH UDP:** `1-65535`
**» OVPN TCP:** `1194`
**» OVPN UDP:** `2200`
**» OVPN SSL:** `990`
**» Proxy Squid:** `3128`
**» UDPGW:** `7100-7300`
**◇━━━━━━━━━━━━━━━━◇**
**» SSH WS:**
`{DOMAIN}:80@{user.strip()}:{pw.strip()}`
**» SSH SSL:**
`{DOMAIN}:443@{user.strip()}:{pw.strip()}`
**» SSH UDP:**
`{DOMAIN}:1-65535@{user.strip()}:{pw.strip()}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link OpenVPN:**
`https://{DOMAIN}:81`
**◇━━━━━━━━━━━━━━━━◇**
**» Save Link Account:**
`https://{DOMAIN}:81/ssh-{user.strip()}.html`
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Payload Websocket ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Kep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expiredMinutes}`
**» 🗓Expired Until:** `{exp}` Minutes
**◇━━━━━━━━━━━━━━━━◇**
"""
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(msg, buttons=inline)
            
            html_content = f"""
<!DOCTYPE html><html lang="en"><head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SSH Account - {user}</title>
    <style>
    
        :root {{
            --primary-color: #7c4dff;
            --secondary-color: #3f2b96;
            --bg-color: #121212;
            --text-color: #ffffff;
            --border-color: #2d4059;
            --card-bg: #1e1e1e;
            --highlight: #b388ff;
        }}
        
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;+
        }}
        
        body {{
            background-color: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }}
        
        .LwDfoPtnIshJfhY {{
            width: 100%;
            max-width: 800px;
            margin: 20px auto;
            padding: 15px;
        }}
        
        .bXMTiZjQaTzYfhd {{
            background-color: var(--card-bg);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
            overflow: hidden;
            margin-bottom: 25px;
        }}
        
        .vEKBZbqSEoEELHA {{
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px 20px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 1px;
        }}
        
        .QpTRSWlvWObRbMk {{
            padding: 20px;
        }}
        
        .ugKbgnRdpGJqzkv {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .fFlebbdONFYVnOx {{
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 15px;
            align-items: center;
        }}
        
        .UFJAknFeRQYhvpy {{
            font-weight: bold;
            width: 140px;
            color: var(--highlight);
            flex-shrink: 0;
        }}
        
        .KXuAzibdYHZWdTt {{
            flex: 1;
            min-width: 0;
            word-break: break-word;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .SOomMzvZlPFErGP, .HaijokxowNCkjtx {{
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 15px;
        }}
        
        .qdMZpIPfYelLTpu {{
            color: var(--primary-color);
            font-weight: bold;
            margin-bottom: 15px;
            font-size: 18px;
        }}
        
        .DttptuUjzeSuQgc {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            overflow-x: auto;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--primary-color);
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }}
        
        .DttptuUjzeSuQgc span {{
            margin-right: 10px;
            word-break: break-all;
            max-width: calc(100% - 70px);
        }}
        
        .DpIdAqRNWsRVmNF pre {{
            background-color: rgba(0, 0, 0, 0.3);
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
            white-space: pre-wrap;
            font-family: monospace;
            font-size: 14px;
            border-left: 3px solid var(--highlight);
            position: relative;
        }}
        
        .DHDWTgWWGrOeqVP {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            background-color: rgba(124, 77, 255, 0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            gap: 10px;
        }}
        
        .KaaPDuZuamkhITk {{
            font-weight: bold;
            color: var(--highlight);
        }}
        
        .OTdoZAuMSPGHHbP {{
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s;
            flex-shrink: 0;
            white-space: nowrap;
        }}
        
        .copy-btn:hover {{
            background-color: var(--secondary-color);
        }}
        
        .AcvlvWBlXILqfdQ {{
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            color: #999;
            font-size: 14px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        
        @media (max-width: 600px) {{
            .fFlebbdONFYVnOx {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .UFJAknFeRQYhvpy {{
                margin-bottom: 5px;
            }}
            
            .KXuAzibdYHZWdTt {{
                width: 100%;
                margin-bottom: 5px;
                justify-content: space-between;
            }}
            
            .OTdoZAuMSPGHHbP {{
                margin-left: auto;
            }}
            
            .DHDWTgWWGrOeqVP {{
                flex-direction: column;
                align-items: flex-start;
            }}
        }}
    </style>
        
    <script>
        function copyToClipboard(text) {{
            navigator.clipboard.writeText(text).then(() => {{
                alert('Copied to clipboard!');
                
            }}).catch(err => {{
                console.error('Failed to copy: ', err);
            }});
        }}
        
        document.addEventListener('DOMContentLoaded', function() {{
            document.getElementById('year').textContent = new Date().getFullYear();
        }});
    </script>
    
</head>

<body>
    <div class="LwDfoPtnIshJfhY">
        <div class="bXMTiZjQaTzYfhd">
        
            <div class="vEKBZbqSEoEELHA">
                SSH Account Information
            </div>
            
            <div class="QpTRSWlvWObRbMk">
                <div class="ugKbgnRdpGJqzkv">
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">Host/IP:</div>
                        <div class="KXuAzibdYHZWdTt">{DOMAIN} / {IP}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">ISP/Location:</div>
                        <div class="KXuAzibdYHZWdTt">{z.get("isp")} / {z.get("city")}</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Username:</div>
                        <div class="KXuAzibdYHZWdTt">{user} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{user}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Password:</div>
                        <div class="KXuAzibdYHZWdTt">{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{pw}')">Copy</button></div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Device Limit:</div>
                        <div class="KXuAzibdYHZWdTt">{iplimit} devices</div>
                    </div>
                </div>
                
                <div class="SOomMzvZlPFErGP">
                <div class="SOomMzvZlPFErGP">
                    <div class="qdMZpIPfYelLTpu">Connection Ports</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">OpenSSH:</div>
                        <div class="KXuAzibdYHZWdTt">22</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Dropbear:</div>
                        <div class="KXuAzibdYHZWdTt">109</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH WS:</div>
                        <div class="KXuAzibdYHZWdTt">80</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH SSL:</div>
                        <div class="KXuAzibdYHZWdTt">443</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH UDP:</div>
                        <div class="KXuAzibdYHZWdTt">1-65535</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN TCP:</div>
                        <div class="KXuAzibdYHZWdTt">1194</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN UDP:</div>
                        <div class="KXuAzibdYHZWdTt">2200</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OVPN SSL:</div>
                        <div class="KXuAzibdYHZWdTt">990</div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">Proxy Squid:</div>
                        <div class="KXuAzibdYHZWdTt">3128</div>
                    </div>
                
                   <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">UDPGW:</div>
                        <div class="KXuAzibdYHZWdTt">7100-7300</div>
                    </div>
                </div>
                
                <div class="HaijokxowNCkjtx">
                    <div class="qdMZpIPfYelLTpu">Connection Details</div>
                    <div class="fFlebbdONFYVnOx">
                    
                        <div class="UFJAknFeRQYhvpy">SSH WS:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:80@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:80@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH SSL:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:443@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:443@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">SSH UDP:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">{DOMAIN}:1-65535@{user}:{pw} <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('{DOMAIN}:1-65535@{user}:{pw}')">Copy</button></div>
                        </div>
                    </div>
                    
                    <div class="fFlebbdONFYVnOx">
                        <div class="UFJAknFeRQYhvpy">OpenVPN:</div>
                        <div class="KXuAzibdYHZWdTt">
                        
                            <div class="DttptuUjzeSuQgc">https://{DOMAIN}:81 <button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('https://{DOMAIN}:81')">Copy</button></div>
                        </div>
                    </div>
                </div>
                
                <div class="DpIdAqRNWsRVmNF">
                    <div class="qdMZpIPfYelLTpu">Websocket Payload</div>
                    <pre>GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]
<button class="OTdoZAuMSPGHHbP" onclick="copyToClipboard('GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]')">Copy</button></pre>
                </div>
                
                <div class="DHDWTgWWGrOeqVP">
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Expired:</span> {expiredMinutes}
                    </div>
                    
                    <div class="expiry-item">
                        <span class="KaaPDuZuamkhITk">Duration:</span> {exp} Minutes
                    </div>
                </div>
            </div>
        </div>
        
        <div class="AcvlvWBlXILqfdQ">
            <p>© <span id="year"></span> RidwanzVPN. All Rights Reserved.</p>
        </div>
        
    </div>

</body></html>
"""
            file_path = f"/var/www/html/ssh-{user.strip()}.html"
            with open(file_path, 'w') as f:
                f.write(html_content)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'check-ssh'))
async def cek_config_ssh(event):
    async def fetch_config_ssh(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username:**")
            user_event = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            check_user = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | wc -l", shell=True).decode().strip()
        except subprocess.CalledProcessError:
            check_user = "0"
            
        if check_user == "0":
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User `{user}` Not Found!**", buttons=inline)
            return
        
        try:
            with open('/etc/xray/isp', 'r') as f:
                isp = f.read().strip()
            with open('/etc/xray/city', 'r') as f:
                city = f.read().strip()
            with open('/etc/xray/domain', 'r') as f:
                domain = f.read().strip()
                
            ssh_username = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | awk '{{print $2}}'", shell=True).decode().strip()
            password = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | awk '{{print $3}}'", shell=True).decode().strip()
            iplimit = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | awk '{{print $4}}'", shell=True).decode().strip()
            expired = subprocess.check_output(f"cat /etc/ssh/.ssh.db | grep -wE {user} | awk '{{print $5\" \"$6\" \"$7}}'", shell=True).decode().strip()
            
        except Exception as e:
            isp = "Unknown"
            city = "Unknown" 
            domain = "Unknown"
            ssh_username = "Unknown"
            password = "Unknown"
            iplimit = "Unknown"
            expired = "Unknown"
                
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Check Config SSH Account ⟩**
**◇━━━━━━━━━━━━━━━━◇**
**» ISP:** {isp}
**» CITY:** {city}
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{domain}`
**» Username:** `{ssh_username}`
**» Password:** `{password}`
**» Limit IP:** `{iplimit}`
**◇━━━━━━━━━━━━━━━━◇**
**» OpenSSH:** `22`
**» Dropbear:** `109`
**» SSH WS:** `80`
**» SSH SSL:** `443`
**» SSH UDP:** `1-65535`
**» OVPN TCP:** `1194`
**» OVPN UDP:** `2200`
**» OVPN SSL:** `990`
**» Proxy Squid:** `3128`
**» UDPGW:** `7100-7300`
**◇━━━━━━━━━━━━━━━━◇**
**» SSH WS:**
`{domain}:80@{ssh_username}:{password}`
**» SSH SSL:**
`{domain}:443@{ssh_username}:{password}`
**» SSH UDP:**
`{domain}:1-65535@{ssh_username}:{password}`
**◇━━━━━━━━━━━━━━━━◇**
**» Link OpenVPN:**
`https://{domain}:81`
**◇━━━━━━━━━━━━━━━━◇**
**» Link Account:**
`https://{domain}:81/ssh-{ssh_username}.html`
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Payload Websocket ⟩**
`GET / HTTP/1.1[crlf]Host: {domain}[crlf]Connection: Keep-Alive[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]`
**◇━━━━━━━━━━━━━━━━◇**
**» 🗓Expired On:** `{expired}`
**◇━━━━━━━━━━━━━━━━◇**
"""
        inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
        await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await fetch_config_ssh(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    async def delete_ssh_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        async with bot.conversation(chat) as user_conv:
            await event.respond("**Enter Username To Be Deleted:**")
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_event).raw_text.strip()
        
        try:
            subprocess.check_output(f"userdel -f {user}", shell=True)
            subprocess.check_output(f"sed -i '/^#ssh# {user}/d' /etc/ssh/.ssh.db", shell=True)
            subprocess.check_output(f"rm -rf /var/www/html/ssh-{user}.html", shell=True)
            subprocess.check_output(f"rm -rf /tmp/delete_ssh_{user}.sh", shell=True)
            subprocess.check_output(f"rm -rf /etc/rs/limit/ssh/ip/{user}", shell=True)
        except subprocess.CalledProcessError:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User** `{user}` **Not Found!**", buttons=inline)
        else:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User `{user}` Successfully Deleted!**", buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await delete_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'lock-ssh'))
async def lock_ssh(event):
    async def lock_ssh_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username To Be Locked:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        try:
            subprocess.check_output(f"passwd -l {user}", shell=True)
        except:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User** `{user}` **Not Found!**", buttons=inline)
        else:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User `{user}` Successfully Locked!**", buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await lock_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        
@bot.on(events.CallbackQuery(data=b'unlock-ssh'))
async def unlock_ssh(event):
    async def unlock_ssh_(event):
        async with bot.conversation(chat) as user:
            await event.respond("**Enter Username To Be Unlocked:**")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text.strip()
        try:
            subprocess.check_output(f"passwd -u {user}", shell=True)
        except:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User** `{user}` **Not Found!**", buttons=inline)
        else:
            inline = [[Button.inline("‹ Back Menu ›", "menu-ssh")]]
            await event.respond(f"**User `{user}` Successfully Unlocked!**", buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await unlock_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    async def show_ssh_(event):
        cmd = "awk -F: '($3>=1000)&&($1!=\"nobody\"){print $1}' /etc/passwd"
        x = subprocess.check_output(cmd, shell=True).decode("ascii").split("\n")
        z = []
        count = 1
        for us in x:
            if us != "":
                z.append(f"{count}. `{us}`")
                count += 1
        if not z:
            await event.answer("No SSH Accounts Found!", alert=True)
            return
        zx = "\n".join(z)
        await event.respond(f"""
**◇━━━━━━━━━━━━━━━━◇**
**⟨ Showing All User SSH ⟩**
**◇━━━━━━━━━━━━━━━━◇**
{zx}
**◇━━━━━━━━━━━━━━━━◇**
**» Total SSH Accounts:** `{str(len(z))}`
**◇━━━━━━━━━━━━━━━━◇**
""", buttons=[[Button.inline("‹ Back Menu ›", "menu-ssh")]])
    
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await show_ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        