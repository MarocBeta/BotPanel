#!/usr/bin/env python3

import requests
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'menu-vmess'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("[ ᴄʀᴇᴀᴛᴇ ᴠᴍᴇss ]", b'create-vmess'),
             Button.inline("[ ᴛʀɪᴀʟ ᴠᴍᴇss ]", b'trial-vmess')],
            [Button.inline("[ ᴅᴇʟᴇᴛᴇ ᴠᴍᴇss ]", b'delete-vmess'),
             Button.inline("[ ʀᴇɴᴇᴡ ᴠᴍᴇss ]", b'renew-vmess')],
            [Button.inline("[ ʟᴏᴄᴋᴇᴅ ᴠᴍᴇss ]", b'lock-vmess'),
             Button.inline("[ ᴜɴʟᴏᴄᴋ ᴠᴍᴇss ]", b'unlock-vmess')],
            [Button.inline("[ sʜᴏᴡ ᴜsᴇʀ ᴠᴍᴇss ]", b'show-vmess'),
             Button.inline("[ ᴄʜᴇᴄᴋ ᴄᴏɴꜰɪɢ ᴠᴍᴇss ]", b'check-vmess')],
            [Button.inline("‹ Main Menu ›", b'menu-manager')]
        ]
        
        try:
            cmd = "grep -c -E \"^### \" \"/etc/xray/config.json\" || echo 0"
            vmc = int(subprocess.check_output(cmd, shell=True))
            vma = vmc // 2
        except subprocess.CalledProcessError:
            vma = 0
        except Exception:
            vma = 0
            
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "Unknown")
            city = z.get("city", "Unknown")
        except Exception:
            isp = "Unknown"
            city = "Unknown"
            
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**    ⟨ Menu VMESS Manager ⟩     **
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» ISP:** `{isp}`
**» City:** `{city}`
**» Total VMESS:** `{vma}` Accounts
**◇━━━━━━━━━━━━━━━━◇**
**» Bot By:** @RidwanzSaputra\n
"""
        await event.edit(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await vmess_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        