#!/usr/bin/env python3

import datetime
from BotPanel import *

start_time = datetime.datetime.now()

async def get_runtime():
    current_time = datetime.datetime.now()
    delta = current_time - start_time
    days = delta.days
    hours = delta.seconds // 3600
    minutes = (delta.seconds % 3600) // 60
    seconds = (delta.seconds % 3600) % 60
    return f"{days} days, {hours} hours, {minutes} minutes, {seconds} seconds."

@bot.on(events.CallbackQuery(data=b'runtime-bot'))
async def runtime_callback(event):
    msg = await get_runtime()
    await event.answer(msg, alert=True)

@bot.on(events.NewMessage(pattern=r"(?:/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu-manager'))
async def menu(event):
    inline = [
        [Button.inline("[ ᴍᴇɴᴜ ssʜ ]", "menu-ssh"), 
        Button.inline("[ ᴍᴇɴᴜ ᴠᴍᴇss ]", "menu-vmess")],
        [Button.inline("[ ᴍᴇɴᴜ ᴠʟᴇss ]", "menu-vless"), 
        Button.inline("[ ᴍᴇɴᴜ ᴛʀᴏᴊᴀɴ ]", "menu-trojan")],
        [Button.inline("[ ᴍᴇɴᴜ sᴇᴛᴛɪɴɢ ]", "menu-setting"), 
        Button.inline("[ ʀᴜɴᴛɪᴍᴇ ʙᴏᴛ ]", "runtime-bot")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("Access Denied!", alert=True)
        except:
            await event.reply("Access Denied!")
    elif val == "true":
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**  ⟨ MAROC BETA AUTOSCRIPT ⟩   **
**◇━━━━━━━━━━━━━━━━◇**
**» Username:** `{sender.username}`
**» UserID:** `{sender.id}`
**◇━━━━━━━━━━━━━━━━◇**
**» Bot Versions:** `v5.0`
**» Bot By:** @MarocBeta
**◇━━━━━━━━━━━━━━━━◇**
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)
            