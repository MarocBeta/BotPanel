#!/usr/bin/env python3

import requests
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'menu-setting'))
async def setting(event):
    async def setting_(event):
        IP = requests.get('https://ipinfo.io/ip').text
        OS = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/\"//g' | sed 's/PRETTY_NAME//g'", shell=True).decode("utf-8").strip()
        TOTAL_RAM = subprocess.check_output("free -m | awk 'NR==2 {print $2}'", shell=True).decode("utf-8").strip()
        USED_RAM = subprocess.check_output("free -m | awk 'NR==2 {print $3}'", shell=True).decode("utf-8").strip()
        CPU = subprocess.check_output("top -bn1 | grep 'Cpu(s)' | sed 's/.*, *\\([0-9.]*\\)%* id.*/\\1/' | awk '{print 100 - $1}'", shell=True).decode("utf-8").strip()
        UPTIME = subprocess.check_output("uptime -p | cut -d \" \" -f 2-10000", shell=True).decode("utf-8").strip()

        inline = [
            [Button.inline("[ ʀᴇʙᴏᴏᴛ sᴇʀᴠᴇʀ ]","reboot-server"), 
            Button.inline("[ ʀᴇsᴛᴀʀᴛ ʙᴏᴛᴘᴀɴᴇʟ ]","restart-botpanel")],
            [Button.inline("[ ʙᴀᴄᴋᴜᴘ sᴇʀᴠᴇʀ ]","backup-server"),
            Button.inline("[ ʀᴇsᴛᴏʀᴇ ʙᴀᴄᴋᴜᴘ ]","restore-backup")],
            [Button.inline("[ ʀᴇsᴛᴀʀᴛ sᴇʀᴠɪᴄᴇs ]", "restart-services"),
            Button.inline("[ ʀᴜɴɴɪɴɢ sᴇʀᴠɪᴄᴇs ]", "running-services")],
            [Button.inline("[ sᴘᴇᴇᴅᴛᴇsᴛ sᴇʀᴠᴇʀ ]", "speedtest-server"),
            Button.inline("[ ᴄʜᴀɴɢᴇ ʙᴀɴɴᴇʀ ssʜ ]", "change-banner")],
            [Button.inline("‹ Main Menu ›","menu-manager")]
        ]
        
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**   ⟨ Menu Setting Manager ⟩  **
**◇━━━━━━━━━━━━━━━━◇**
**» IP Adress:** `{IP}`
**» OS System:** `{OS}`
**» Total RAM:** `{TOTAL_RAM} / {USED_RAM} MB`
**» CPU Usage:** `{CPU}%`
**» Uptime:** `{UPTIME}`
**◇━━━━━━━━━━━━━━━━◇**
**» Bot By:** @RidwanzSaputra\n
"""
        await event.edit(msg, buttons=inline)

    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await setting_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        