#!/usr/bin/env python3

import requests
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'menu-vless'))
async def vless(event):
    async def vless_(event):
        inline = [
            [Button.inline("[ ᴄʀᴇᴀᴛᴇ ᴠʟᴇss ]", b'create-vless'),
             Button.inline("[ ᴛʀɪᴀʟ ᴠʟᴇss ]", b'trial-vless')],
            [Button.inline("[ ᴅᴇʟᴇᴛᴇ ᴠʟᴇss ]", b'delete-vless'),
             Button.inline("[ ʀᴇɴᴇᴡ ᴠʟᴇss ]", b'renew-vless')],
            [Button.inline("[ ʟᴏᴄᴋᴇᴅ ᴠʟᴇss ]", b'lock-vless'),
             Button.inline("[ ᴜɴʟᴏᴄᴋ ᴠʟᴇss ]", b'unlock-vless')],
            [Button.inline("[ sʜᴏᴡ ᴜsᴇʀ ᴠʟᴇss ]", b'show-vless'),
             Button.inline("[ ᴄʜᴇᴄᴋ ᴄᴏɴꜰɪɢ ᴠʟᴇss ]", b'check-vless')],
            [Button.inline("‹ Main Menu ›", b'menu-manager')]
        ]
        
        try:
            cmd = "grep -c -E \"^#& \" \"/etc/xray/config.json\" || echo 0"
            vlx = int(subprocess.check_output(cmd, shell=True))
            vla = vlx // 2
        except subprocess.CalledProcessError:
            vla = 0
        except Exception:
            vla = 0
            
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            isp = z.get("isp", "Unknown")
            city = z.get("city", "Unknown")
        except Exception:
            isp = "Unknown"
            city = "Unknown"
            
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**    ⟨ Menu VLESS Manager ⟩     **
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» ISP:** `{isp}`
**» City:** `{city}`
**» Total VLESS:** `{vla}` Accounts
**◇━━━━━━━━━━━━━━━━◇**
**» Bot By:** @RidwanzSaputra\n
"""
        await event.edit(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await vless_(event)
    else:
        await event.answer("Access Denied!", alert=True)
