#!/usr/bin/env python3

import requests
import subprocess
from BotPanel import *

@bot.on(events.CallbackQuery(data=b'menu-ssh'))
async def ssh(event):
    async def ssh_(event):
        inline = [
            [Button.inline("[ ᴄʀᴇᴀᴛᴇ ssʜ ]", b'create-ssh'),
             Button.inline("[ ᴛʀɪᴀʟ ssʜ ]", b'trial-ssh')],
            [Button.inline("[ ᴅᴇʟᴇᴛᴇ ssʜ ]", b'delete-ssh'),
             Button.inline("[ ʀᴇɴᴇᴡ ssʜ ]", b'renew-ssh')],
            [Button.inline("[ ʟᴏᴄᴋᴇᴅ ssʜ ]", b'lock-ssh'),
             Button.inline("[ ᴜɴʟᴏᴄᴋᴇᴅ ssʜ ]", b'unlock-ssh')],
            [Button.inline("[ sʜᴏᴡɪɴɢ ᴜsᴇʀ ssʜ ]", b'show-ssh'),
             Button.inline("[ ᴄʜᴇᴄᴋ ᴄᴏɴꜰɪɢ ssʜ ]", b'check-ssh')],
            [Button.inline("‹ Main Menu ›", b'menu-manager')]
        ]

        cmd = "awk -F: '($3>=1000)&&($1!=\"nobody\"){print $1}' /etc/passwd | wc -l"
        ssh_users = int(subprocess.check_output(cmd, shell=True))

        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━◇**
**    ⟨ Menu SSH Manager ⟩     **
**◇━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» City:** `{z["city"]}`
**» Total SSH:** `{ssh_users}` Accounts
**◇━━━━━━━━━━━━━━━━◇**
**» Bot By:** @RidwanzSaputra\n
"""
        await event.edit(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await ssh_(event)
    else:
        await event.answer("Access Denied!", alert=True)
        